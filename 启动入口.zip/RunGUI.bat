@echo off
rem ============================================================
rem  DeepFaceLab 4.1 - launch the GUI
rem  Double-click this file. No console window stays open.
rem ============================================================
setlocal
cd /d "%~dp0"

rem Electron must not run in plain-node mode
set "ELECTRON_RUN_AS_NODE="

set "ELECTRON=desktop\node_modules\electron\dist\electron.exe"

rem Backend interpreter: unified first (merged env), then the old split layout.
rem Keep this list in sync with desktop\main.js PY_CANDIDATES.
set "PY=%CD%\runtime\unified\pythonw.exe"
if not exist "%PY%" set "PY=%CD%\runtime\server\Scripts\pythonw.exe"
if not exist "%PY%" set "PY=%CD%\runtime\engine\pythonw.exe"

if not exist "%ELECTRON%" goto no_electron
if not exist "%PY%" goto no_python

start "" /D "%CD%\desktop" "%ELECTRON%" .
exit /b 0

:no_electron
echo [ERROR] Electron is not installed.
echo.
echo   Missing: %ELECTRON%
echo   Fix: open a terminal in the desktop folder and run
echo.
echo       npm install
echo.
pause
exit /b 1

:no_python
echo [ERROR] Portable Python runtime not found.
echo.
echo   Missing: %PY%
echo   Expected one of:\r
    runtime\unified\pythonw.exe\r
    runtime\server\Scripts\pythonw.exe\r
    runtime\engine\pythonw.exe
echo.
pause
exit /b 1
